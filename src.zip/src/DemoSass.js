import React from 'react'
import './DemoSass.scss'

function DemoSass() {
  return (
   

    <div className='main'>
        <label>Home</label>
        <label>About</label>
        <label>setting</label>
        <label>Dashboard</label>
        <label className='log'>Logout</label>
    <h2>hello how are you</h2>
    </div>
    
  )
}

export default DemoSass